export default function CustomMarker() {
  return (
    <>
      <div
        style={{
          backgroundColor: "red",
          width: "20px",
          height: "20px",
          borderRadius: "50%",
          border: "2px solid white",
        }}
      ></div>
    </>
  );
}
